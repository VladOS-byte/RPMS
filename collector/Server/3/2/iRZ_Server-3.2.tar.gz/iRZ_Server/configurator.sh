#!/bin/bash

export NCURSES_NO_UTF8_ACS=0;

# localpath=$(echo $0 | sed "s/configurator.sh$//g")
localpath="/usr/local/iRZ_Server"

echo $1

if [[ ! $1 == "--hard"  && ! -z $(bash $localpath/dist/checkRequirements.sh $localpath/configurator.sh) ]]
then
	bash $localpath/dist/checkRequirements.sh $localpath/configurator.sh;
	exit 1;
fi;

#return: 
#args: 1. message
#process: print message to log file and standart output with current time
log() {
	if [[ -f "/etc/iRZ_Server_3/config/loggers.ini" && $(grep -e "^1$" "/etc/iRZ_Server_3/config/loggers.ini" | wc -l) == 1 ]]
	then
		echo "[$(date '+%Y.%m.%d %H:%M:%S.')$(date '+%s%N' | cut -b11-13)] $1" >> "$localpath/logs/$(date '+%d-%m-%Y').txt";
	fi;
	echo $1 > /dev/stderr;
}

#return: file or dir name
#args: 1. file or dir name 
#progress: if file or dir don't exist, execute configserver.sh and create files and dirs
get_server_path() {
	if [[ ! -f "/etc/iRZ_Server_3/$1" && ! -d "/etc/iRZ_Server_3/$1" ]]
	then
		bash $localpath/dist/configserver.sh;
		
		case $? in
		2)	
			echo 'Bye' > /dev/stderr;
			turner="TERMINATE";
			exit 0;;
		esac;
	fi;
	
	if [ -n "$(echo '$1' | grep -e 'temp')" ]
	then
		touch "/etc/iRZ_Server_3/$1";
	fi;
	
	echo "/etc/iRZ_Server_3/$1";
}

#return: text with titles
#args: 1. title, 2. content
#progress: print content in standart output with begin and end titles
print_like_file() {
	echo -e "\n┌───────────────────────────────────┤$1├───────────────────────────────────┐";
	echo -e "$2" | awk ' { print "\t"$0 } ';
	echo -e "└───────────────────────────────────┤$1├───────────────────────────────────┘\n";
}

#return: text in file with titles
#args: 1. title, 2. filename
#progress: print file in standart output with begin and end titles
print_file() {
	echo -e "\n┌───────────────────────────────────┤$1├───────────────────────────────────┐"
	sed 's/:/ = /
		s/_/ /g' < $2;
	echo -e "└───────────────────────────────────┤$1├───────────────────────────────────┘\n"
}

#return: rules for some account
#args: 
#progress: ask about account's permissions
show_dialog() {
	read -p "What access will new account have?[F-full permission/C-custom permission]: " admin;
	case ${admin^^} in
	F)
		rules="0 1 2 3 4 5 6";;
	C)
		echo -e "Choose options:\n1 COMMANDS\n2 MODIFY SETTINGS\n3 UPDATE SETTINGS\n4 ADD MODEM\n5 MODEM DESCRIPTION\n6 FIRMWARE UPGRADE" > /dev/stderr;
		read -p "Enter option numbers separated by spaces: " rules;
		if [ ! "$?" = 0 ]
		then
			rules="c";
		fi;;
	esac;
	echo $rules;
}

#return: rules joined by coma
#args: rules by show_dialog()
#progress: compile string with permissons for SQL query
rules_for_SQL() {
	a="";
	if [ -n "$(echo $1 | grep '0')" ]
	then
		a="0";
	else
		a="1";
	fi;
	for i in $(seq 1 6);
	do 
		if [ -n "$(echo $1 | grep $i)" ]
		then
			a+=",1";
		else
			a+=",0";
		fi;
	done;
	echo $a;
}

#return: 
#args: 1. filename from, 2. filename to
#progress: copy data from file $1 to $2
copy_file() {
	awk '{ print $0 }' < $1 > $2
}

#return: 
#args: 1. regex for sed, 2. filename
#progress: execute sed with regex for file
sed_file() {
	sed -e "$1" $2 > $(get_server_path 'temp/tmp') || cat $2 > $(get_server_path 'temp/tmp'); 
	copy_file $(get_server_path 'temp/tmp') $2; 
	rm $(get_server_path 'temp/tmp'); 
}

#return: value by parameter from file
#args: 1. parameter in file, 2. filename
#progress: search value by parameter in file
get_value() {
	echo $(grep "$1" $(get_server_path $2) | sed 's/ = /=/g' | cut -d= -f'2');
}

#return: 
#args: 1. parameter in config file, 2. parameter in temp file, 3. config filename
#progress: save data of parameter $1 from temp file to config file by parameter $2
save_parameters() {
        sed_file "s/^$1=.*/$1=$(get_value $2 'temp/temp' | sed 's/\//\\\//g')/g" $3
}

#return: 
#args: 1. parameter in temp file, 2. config filename
#progress: append data of parameter from temp file to config file
push_parameter() {
	echo $(get_value $1 'temp/temp') >> $2
}

#return: 
#args: 1. config filename, [2..n]. array of parameters
#progress: append data of parameters from temp file to config file
push_parameters() {
	rm $1;
	for i in ${@:2}
	do
		push_parameter $i $1
	done;
}

#return:
#args: 1. parameter in temp file, 2. config filename
#progress: append data of parameter from temp file to config file
push_parameter_proto() {
	proto=$(get_value 'proto' 'temp/temp' | tr -d '\n' | tr -d '\r');
	echo "mail.$proto.$1=$(get_value $1 'temp/temp')" >> $2
}

#return:
#args: 1. config filename, 2. protocol, [3..n]. array of parameters
#progress: append data of parameters from temp file to config file
push_parameters_proto() {
	rm $1;
	for i in ${@:3}
	do
		push_parameter_proto $i $1
	done;
}


#return: written value
#args: 1. keyword, 2. action
#progress: read value from standart input with special format 
read_smth() {
	read -p "Enter $1 for $2: " name;
	name=$(echo $name | sed 's/ /_/g');
	name=${name,,};
	if [ -z "$name" ]
	then 
		log "Warning: ${1^} is empty.";
	fi;
	echo $name;
}

#return: value by parameter from file
#args: 1. parameter in config file
#progress: search value by parameter in config file
get_parameter() {
	echo $(get_value $1 'config/parameters.ini');
}


host="127.0.0.1";
port="3306";
user="admin";
pass="5492";

	
#return:
#args:
#progress: check if mysql connected
check_mysql() {
	check=$(mysql -h $host -P $port -u$user -p$pass -e "SHOW DATABASES LIKE 'irzserver3';");
	if [[ "$?" == "0" ]]
	then
		if [[ -z "$check" ]]
		then
			echo "NOT LOAD";
		else
			echo "OK";
		fi;
	else
		echo "ERROR";
	fi;
}


#return:
#args:
#progress: update parameters: host, port, user, pass from config file
upd_parameters() {
	host=$(get_parameter "msh");
	port=$(get_parameter "msport");
	user=$(get_parameter "msu");
	pass=$(get_parameter "mspass");

	if [[ ! "$(check_mysql)" == "ERROR" ]]
	then
		mysql -h $host -P $port -u$user -p$pass -e "CREATE DATABASE IF NOT EXISTS irzserver3 CHARACTER SET = utf8;" && mysql -h $host -P $port -u$user -p$pass -D irzserver3 < "$localpath/src/DB/mydbL.sql" 1> /dev/null 2> /dev/null;
	fi;
}


#return:
#args: $1 - path to dump
#progress: revert database by loading from dump
revert_database() {
	read -p "Do you want to revert Database?[Y]: " ans;
	if [ "${ans^^}" = "Y" ] 
	then
		mysqldump -h $host -P $port -u$user -p$pass --result-file=$1 irzserver3;
		log "Database reverted."; 
	fi;
}


#return: filepath
#args: 1. action
#progress: ask user to choose a file for action
choose_file() {
	echo $(dialog --stdout --title "Choose a file for $1" --begin 5 10 --fselect $PWD/ $((LINES-20)) $((COLUMNS-20)));
}


#return: [0 - wrong username or password, 1 - OK]
#args:
#progress: search account with name $user and written password in db
enter_admin_password() {
	read -p "Enter admin\`s password: " password;
	
	upd_parameters;
	ans=$(mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "SELECT * FROM users where name='admin' and password=\"$(echo -n $password | md5sum | awk '{print $1}')\";" | tail -n +2 | wc -l); 
			
	echo $ans;
}


#return:
#args:
#progress: turn on clearing commands event, if it off. 
turn_on_scheduler() {
	upd_parameters;
	if [ \"$(mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "SHOW GLOBAL VARIABLES LIKE 'event_scheduler';" | tail -n +2 | awk '{ print $2 }')\" = "OFF" ]
	then
		mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "SET GLOBAL event_scheduler = ON;";
	fi;
}

pid="pidS"
turner=""


#return:
#args:
#progress: turn on (off) server, if it off (on).
turn_server() {
	if [ "$turner" != "Service is unavalible" ]
	then
		if [[ "$(systemctl check iRZ_Collector_Server_3)" == "active" ]]
		then
			systemctl stop iRZ_Collector_Server_3.service;
			# kill -9 $(cat $(get_server_path "temp/$pid"));
			# rm $(get_server_path "temp/$pid");
			log "STOP Service iRZ_Collector_Server";
			turner="Start service";
		else
			systemctl start iRZ_Collector_Server_3.service;
			# nohup java -jar dist/Service.jar > logs/irz.err &
			# echo $! > $(get_server_path "temp/$pid");
			log "Start Service iRZ_Collector_Server";
			turn_on_scheduler;
			turner="Stop service";
		fi;
		sleep 1s;
	else
		log "Error: Service is unavailible";
	fi;
}


#return: [1 - process with pid already launched, empty string - else]
#args: file with pid
#progress: check if app is avalible to start / stop.
check_pid() {
	if [[ -f "$(get_server_path 'temp/')$1" && ! -z "$(ps aux | grep -wv "grep" | grep server.sh | sed -r 's/\s+/ /g' | cut -d' ' -f2 | grep $(cat $(get_server_path 'temp/')$1))" ]]
	then
		echo "1";
	else
		echo "";
	fi;
}


#return: string item of service status manipulation
#args:
#progress: check if service is avalible to start / stop.
check_service() {
	if [ "$turner" != "Service is unavalible" ]
	then
		if [[ "$(systemctl check iRZ_Collector_Server_3)" == "active" ]]
		then
			turner="Stop service";
		else
			turner="Start service";
		fi;
	fi;
	echo $turner;
}


#return: OK, if all available. List of ports else.
#args: 1 - port from, 2 - port to
#progress: check if all ports in range are avalible.
check_ports() {
	used_ports=$(netstat -antlp | sed -r 's/\s+/ /g' | cut -d' ' -f4,6,7 | egrep -o -e ":[0-9A-Z ]+/" | egrep -o -e "[0-9A-Z ]+(LISTEN(ING)?|ESTABLISHED)[0-9A-Z ]+" | {
		while read line;
		do
			port_line=$(echo $line | awk '{ print $1 }');
			pid_line=$(echo $line | awk '{ print $3 }');
			if [[ -f $(get_server_path 'temp/')$pid && ! "$pid_line" == "$(cat $(get_server_path 'temp/')$pid)" && ! -z "$(check_service | grep "Stop")" && "$port_line" -ge $1 && "$port_line" -le $2 ]]
			then
				echo "$port_line";
			fi;
		done;
	});
	if [[ -z "$used_ports" ]]
	then
		echo "OK";
	else
		echo "$used_ports";
	fi;
}


#return: OK device available. Error else.
#args:
#progress: check if local port is avalible.
check_local_device() {
	local_device_port=$(get_parameter "ttyX");
	if [[ -z "$local_device_port" || ! -z $(ls /dev | grep $(echo "$local_device_port" | sed 's/\/dev\///g')) ]]
	then
		echo "OK";
	else
		echo "ERROR";
	fi;
}


#return:
#args: title
#progress: change parameter by user
change_parameters() {
	read -p "Enter parameter for changing: " parameter; 

	for b in $(grep -i -e "${parameter,,}.* = " $(get_server_path 'temp/temp') | sed 's/ = /=/g' | sed 's/ /_/g' | cut -d"=" -f'1'); 
	do
		read -p "Do you want to change parameter ($(echo $b | sed 's/_/ /g'))? [Y]: " ans; 

		if [ "${ans^^}" = "Y" ] 
		then 
			read -p "Enter new value for parameter: " val;
			pattern="$(get_value "$(echo $b | sed 's/\-/\\\-/g' | sed 's/\[/\\\[/g' | sed 's/\]/\\\]/g')" 'config/regex.ini' | sed 's/\\//g')";
			if [[ ! $val =~ ^$pattern$ ]]
			then
				log "Error: Pattern mismatch ($pattern)";
				break;
			fi;

			if [ -n "$(echo $val | grep '[\\:]')" ]
			then 
				log "Error: Unsupported symbol.";
				break;
			fi;

			sed_file "s/$(echo $b | sed 's/\-/\\\-/g' | sed 's/_/ /g' | sed 's/\[/\\\[/g' | sed 's/\]/\\\]/g') = .*/$(echo $b | sed 's/_/ /g' | sed 's/\[/\\\[/g' | sed 's/\]/\\\]/g') = $(echo $val | sed 's/\//\\\//g')/g" $(get_server_path 'temp/temp');
			save=1;
			break; 
		fi; 
	done;

	print_file "$1" "$(get_server_path 'temp/temp')";
}


#return:
#args:
#progress: cancel editing of parameters by user
cancel_editing_parameters() {
	if [ $save = 1 ]
	then
		read -p "Warning: All unsaved changes will be lost. Are you sure? [Y]: " ans;
		if [ ! "${ans^^}" = "Y" ]
		then
			break;
		fi;
	fi;

	rm $(get_server_path 'temp/temp');
	save=2;
}

#return:
#args:
#progress: print current status of service and dependencies
print_status() {
	print_like_file "STATUS" "Database: $(check_mysql)\nDevice local com port: $(check_local_device)\nPort range: $(check_ports $(get_parameter 'dpl') $(get_parameter 'dpr'))\nAddress for dispatcher application: $(check_ports $(get_parameter 'disport') $(( $(get_parameter 'disport') + 1 )))\nAddress for devices: $(check_ports $(get_parameter 'devport') $(get_parameter 'devport'))\nService: $(systemctl check iRZ_Collector_Server_3)\n\r├───────────────────────────────────┤Logging├──────────────────────────────────┤\n$(cat $localpath/logs/startlog.log | fold -w70 )";
}

#return:
#args:
#progress: print program version
print_version() {
	echo -e "\n\n   IRZ       IRZ    IRZ       IRZ       IRZIRZIRZ    IRZ    IRZIRZIRZ    IRZ    IRZIRZ\n IRZIRZI   IRZIRZI  IRZ       IRZ       IRZIRZIRZ  IRZIRZI  IRZIRZIRZ  IRZIRZI  IRZIRZIR \nIRZ   IRZ IRZ   IRZ IRZ       IRZ       IRZ       IRZ   IRZ    IRZ    IRZ   IRZ IRZ   IRZ\nIRZ       IRZ   IRZ IRZ       IRZ       IRZ       IRZ          IRZ    IRZ   IRZ IRZ   IRZ\nIRZ       IRZ   IRZ IRZ       IRZ       IRZIRZIRZ IRZ          IRZ    IRZ   IRZ IRZIRZIR \nIRZ       IRZ   IRZ IRZ       IRZ       IRZIRZIRZ IRZ          IRZ    IRZ   IRZ IRZIRZ\nIRZ       IRZ   IRZ IRZ       IRZ       IRZ       IRZ          IRZ    IRZ   IRZ IRZ IRZ\nIRZ   IRZ IRZ   IRZ IRZ       IRZ       IRZ       IRZ   IRZ    IRZ    IRZ   IRZ IRZ  IRZ\n IRZIRZI   IRZIRZI  IRZIRZIRZ IRZIRZIRZ IRZIRZIRZ  IRZIRZI     IRZ     IRZIRZI  IRZ   IRZ\n   IRZ       IRZ    IRZIRZIRZ IRZIRZIRZ IRZIRZIRZ    IRZ       IRZ       IRZ    IRZ   IRZ" && echo -e "\n\n\t\t\t           IRZIRZI       IRZIRZI\n\t\t\t          IRZIRZIRZ     IRZIRZIRZ\n\t\t\t          IRZ   IRZ     IRZ   IRZ\n\t\t\t                IRZ          IRZ\n\t\t\tIRZ   IRZ     IRZ           IRZ \n\t\t\tIRZ   IRZ     IRZ          IRZ  \n\t\t\t IRZ IRZ        IRZ       IRZ\n\t\t\t IRZ IRZ  IRZ   IRZ  I   IRZ\n\t\t\t  IRZIR   IRZIRZIRZ IRZ IRZIRZIRZ\n\t\t\t   IRZ     IRZIRZI   I  IRZIRZIRZ\n";
}

if [[ ! -z "$(check_pid "pid")" ]]
then
	echo "Warning: Application already launched";
	echo "Bye";
	exit 0;
else
	echo $$ > $(get_server_path "temp/pid");
fi;


# if [ "$localpath" != "dist/" ]
# then
# 	turner="Service is unavalible"
# 	read -p "Warning: Start from unsupported directory. Some functions may not work. Continue? [Y/N]: " stop;
# 	if [ "${stop^}" = "N" ]
# 	then
# 		echo "Bye";
# 		exit 0;
# 	fi;
# fi;

upd_parameters;
print_version;
print_status;


while [ "$turner" != "TERMINATE" ]
do
	select item in Configuration "Email configuration" Accounts DataBase "$(check_service)" Status Exit;
	do
		case $item in 
		Configuration)
			
			save=0;
			
			copy_file $(get_server_path 'config/parameters.ini') $(get_server_path 'temp/temp')
			print_file "PARAMETERS" $(get_server_path 'temp/temp')
	
			while [ $save != 2 ]
			do
				select option in Change Save Cancel
				do
					case $option in 
					Change)

						change_parameters "PARAMETERS";;

					Save)
						if [ $save = 1 ]
						then
							copy_file $(get_server_path 'temp/temp') $(get_server_path 'config/parameters.ini');
							save_parameters "LOCAL_PORT" "devport" $(get_server_path 'config/mainConfig.properties');
							save_parameters "CLIENT_PORT" "disport" $(get_server_path 'config/mainConfig.properties');
							save_parameters "NEW_DEVICES_BEHAVIOUR" "adddev" $(get_server_path 'config/mainConfig.properties');
							save_parameters "DEVICE_LOCAL_COM_PORT" "ttyX" $(get_server_path 'config/mainConfig.properties');

							save_parameters "mode" "mmode" $(get_server_path 'config.properties');
							
							push_parameters $(get_server_path 'config/db.ini') 'msh' 'msport' 'msu' 'mspass';
							upd_parameters;
							
							save_parameters "histDays" "history" $(get_server_path 'config/config.properties');
							mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "ALTER EVENT clear_commands_event DO call clear_commands($(grep 'history' $(get_server_path 'temp/temp') | sed 's/ = /=/g' | sed 's/\[/\\\[/g' | sed 's/\]/\\\]/g' | cut -d'=' -f'2'));"  1> /dev/null 2> /dev/null;
							turn_on_scheduler;
							
							push_parameters $(get_server_path 'config/ipport.ini') 'dip' 'dip' 'dpl' 'dpr';
							echo '10' >> $(get_server_path 'config/ipport.ini');
							
							push_parameters $(get_server_path 'config/loggers.ini') 'log';

							# push_parameters $(get_server_path 'config/warning.ini') 'warn';
							
							push_parameters $(get_server_path 'config/sockets.ini') 'osock';
							log "All changes saved.";
							read -p "Warning: All changes will be applied after restart. Restart service? [Y]: " ans;
							if [ "${ans^^}" = "Y" ]
							then
								turn_server;
								if [ "$(check_service)" = "Start service" ]
								then
									turn_server;
								fi;
							fi;
						fi;
						 
						rm $(get_server_path 'temp/temp');
						save=2;;
					Cancel)
						if [ $save = 1 ]
						then
							read -p "Warning: All unsaved changes will be lost. Are you sure? [Y]: " ans;
							if [ ! "${ans^^}" = "Y" ]
							then
								break;
							fi;
						fi;
						rm $(get_server_path 'temp/temp');
						save=2;;
					esac;
					break;
				done;
			done;;

		"Email configuration")
			
			save=0;

			copy_file $(get_server_path 'config/mail.ini') $(get_server_path 'temp/temp');
			print_file "EMAIL PARAMETERS" $(get_server_path 'temp/temp');

			while [ $save != 2 ]
			do
				select option in Change Check Save Cancel
				do
					case $option in
					Change)

						change_parameters "EMAIL PARAMETERS";;			
		
					Check)

						proto=$(get_value 'proto' 'temp/temp' | tr -d '\n' | tr -d '\r');
						if [[ ! "$proto" == "smtp" ]]
						then	
							echo "Unsupported protocol '$proto' for checking. Coming soon.";
						else
							read -p "Enter destination email for checing email configuration: " email_to;
							pat="$(get_value "user" 'config/regex.ini' | sed 's/\\//g')"
						
							if [[ ! $email_to =~ ^$pat$ ]]
							then
								log "Error: This email is unsupported.";
								break;
							fi;

							email_from=$(get_value 'user' 'temp/temp' | tr -d '\n' | tr -d '\r');

							auth=$(get_value 'auth' 'temp/temp' | tr -d '\n' | tr -d '\r');

							if [ "$auth" = "true" ]
							then
								auth="-S smtp-auth=login -S smtp-auth-user="$email_from" -S smtp-auth-password="$(get_value 'pass' 'temp/temp' | tr -d '\n' | tr -d '\r')"";
							else
								auth="";
							fi;

							tls=$(get_value 'starttls.enable' 'temp/temp' | tr -d '\n' | tr -d '\r');

							if [ "$tls" = "true" ]
							then
								tls="-S smtp-use-starttls";
							else
								tls="";
							fi;

							ssl=$(get_value 'ssl.enable' 'temp/temp' | tr -d '\n' | tr -d '\r');

							if [ "$ssl" = "true" ]
							then
								ssl="-S ssl-verify=strict";
							else
								ssl="";
							fi;

							host_mail=$(echo "-S smtp=smtps://$(get_value 'host' 'temp/temp' | tr -d '\n' | tr -d '\r')");
							mail -v -s "Test" $host_mail":465" $auth $tls $ssl -r $email_from $email_to <<< "This is a test email from iRZ Collector 3.2. Do not answer it.";
						fi;;

					Save)

						if [ $save = 1 ]
						then
							copy_file $(get_server_path 'temp/temp') $(get_server_path 'config/mail.ini');

							push_parameters_proto $(get_server_path 'config/mail.properties') 'proto' 'user' 'pass' 'auth' 'starttls.enable' 'host' 'ssl.enable';
							save_parameters 's=mail.transport.protocol' 'proto' $(get_server_path 'config/mail.properties');

							log "All changes saved.";
						fi;
		
						rm $(get_server_path 'temp/temp');
						save=2;;

					Cancel)
						if [ $save = 1 ]
						then
							read -p "Warning: All unsaved changes will be lost. Are you sure? [Y]: " ans;
							if [ ! "${ans^^}" = "Y" ]
							then
								break;
							fi;
						fi;

						rm $(get_server_path 'temp/temp');
						save=2;;
					esac;

					break;
				done;
			done;;

		Accounts)
		
			ans=$(enter_admin_password);
			
			if [ -n "$(echo $ans | grep '0')" ]
			then
				log "Error: Wrong password for admin.";
				break;
			fi;
			
			save=0;
			mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "SELECT * FROM users" | tail -n +2 | awk '
			{
				c=$1": ";
				if ($3 == 0) {
					c=sprintf("%s%i%s", c, 0, " ");
				}
				for (i = 4; i <= 9; ++i) {
					if ($i == 1) {
						c=sprintf("%s%i%s", c, i-3, " ");
					}
				}
				print c;
			}' > $(get_server_path 'temp/users');
		
			while [ $save != 2 ]
			do
				print_like_file "USERS" "$(cat $(get_server_path "temp/users"))";
				echo -e "Name = Options(0 - FULL PERMISSION 1 - COMMANDS 2 - MODIFY SETTINGS 3 - UPDATE SETTINGS 4 - ADD MODEM 5 - MODEM DESCRIPTION 6- FIRMWARE UPGRADE)\n";
				
				select option in New Edit Remove Cancel
				do
					case $option in
					New)
						name=$(read_smth "name" "new account");
						
						if [ -z "$name" ]
						then
							break;
						fi;
		
						if [ -n "$(grep $name $(get_server_path 'temp/users'))" ]
						then 
							log "Error: Account with name $name already existed.";
							break;
						fi;

						pat='^[a-zA-Z0-9]+$';
						if [[ ! $name =~ $pat ]]
						then 
							log "Error: Name has unsupported symbol.";
							break;
						fi; 
						
						word=$(read_smth "password" "new account");
						
						if [[ ! $word =~ $pat ]]
						then
							log "Error: This password is unsupported.";
							break;
						fi;
						
						rules=$(show_dialog);
						if [ "$rules" = "c" ]
						then 
							break;
						fi;
						access=$(rules_for_SQL "$rules");
						
						mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "INSERT INTO users(name, password, access, enc_com, mod_modem_set, update_set, add_delete_modem, mod_modem_des, firm_upgrade) value ('$name', \"$(echo -n $word | md5sum | awk '{print $1}')\",$access);"
						
						echo -e "$name: $rules" >> $(get_server_path "temp/users");
						log "New account $name created.";;
					Edit)
						name=$(read_smth "name" "editing")

						for b in $(grep -i "$name" $(get_server_path "temp/users") | cut -d: -f'1'); 
						do	
							read -p "Do you want to edit user ($(echo $b | sed 's/_/ /g'))[Y]: " ans; 

							if [ "${ans^^}" = "Y" ] 
							then
								if [ "$b" = "admin" ]
								then
									select edit_option in "Edit password" Cancel
									do
										case $edit_option in
											"Edit password")
												word=$(read_smth "new password" "$b");

												if [[ ! $word =~ $pat ]]
												then
													log "Error: This password is unsupported.";
													break;
												fi;
												mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "UPDATE users SET password=\"$(echo -n $word | md5sum | awk '{print $1}')\" WHERE name='$b';";
												break;;
											Cancel)
												break;;
										esac;
										break;
									done;
								else
									select edit_option in "Edit password" "Edit rules" Cancel
									do
										case $edit_option in
											"Edit password")
												word=$(read_smth "new password" "$b");

												if [[ ! $word =~ $pat ]]
												then
													log "Error: This password is unsupported.";
													break;
												fi;
												mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "UPDATE users SET password=\"$(echo -n $word | md5sum | awk '{print $1}')\" WHERE name='$b';";
												break;;
											"Edit rules")
												rules=$(show_dialog)
												if [ "$rules" = "c" ]
												then 
													break;
												fi;

												str_access=$(rules_for_SQL "$rules" | sed 's/,/ /g');

												read -r -a access <<< "$str_access";
												echo ${access[*]};

												mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "UPDATE users SET access=${access[0]}, enc_com=${access[1]}, mod_modem_set=${access[2]}, update_set=${access[3]}, add_delete_modem=${access[4]}, mod_modem_des=${access[5]}, firm_upgrade=${access[6]} WHERE name='$b';";
												
												sed_file "s/^$b:.*/$b: $rules/g" $(get_server_path "temp/users");
												break;;
											Cancel)
												break;;
										esac;
										break;
									done;
								fi;
								
								log "Account $b edited.";
								break; 
							fi;
						done;;
					Remove)
						name=$(read_smth "name" "removing")
		
						for b in $(grep -i "$name" $(get_server_path "temp/users") | cut -d: -f'1'); 
						do
							if [ "$b" = "admin" ]
							then
								continue;
							fi;
							
							read -p "Do you want to remove user ($(echo $b | sed 's/_/ /g'))[Y]: " ans;
							
							if [ "${ans^^}" = "Y" ] 
							then
								mysql -h $host -P $port -u$user -p$pass -D irzserver3 -e "DELETE FROM users WHERE name='$b';"
								sed_file "/^$b:.*/d" $(get_server_path "temp/users");
								log "Account $b removed.";
								break; 
							fi;
						done;;
					Cancel)
						save=2;
						break;;
					esac;
					break;
				done;
			done;
			rm $(get_server_path 'temp/users');;

		DataBase)
			read -p "Do you want to change Database or load current state? iRZ Collector Service will be stopped.[Y]: " ans;

			if [ ! "${ans^^}" = "Y" ]
			then
				break;
			fi;

			if [ "$(check_service)" = "Stop service" ]
			then
				turn_server;
			fi;

			ans=$(enter_admin_password);
			
			if [ -n "$(echo $ans | grep '0')" ]
			then
				log "Error: Wrong password for admin.";
				break;
			fi;
			
			select option in Save Load "From file" Cancel
			do
				case $option in 
				Save)
					path=$(choose_file "saving");
					if [ -n "$path" ]
					then
						mysqldump -h $host -P $port -u$user -p$pass --result-file=$path irzserver3;
						log "Complite: DB was saved in $path.";
					fi;
					break;;

				Load)
					path=$(choose_file "downloading");
					sentence="Database: irzserver";
					if [[ -n "$path" && ! -z "$(grep "$sentence" < $path)" ]]
					then
						log "Creating dump of current DB...";
						mysqldump -h $host -P $port -u$user -p$pass --result-file="$(get_server_path temp/dump.sql)" irzserver3;
						log "Success.";

						version=$(sed "s/$sentence/\n$sentence/g" < $path | grep "$sentence" | sed 's/[^0-9]//g');
						log "Dump version $version.";
						if [[ -z "$version" ]]
						then
							version="temp";
							mysql -h $host -P $port -u$user -p$pass -e "CREATE DATABASE IF NOT EXISTS irzservertemp CHARACTER SET = utf8;";
						fi;

						load_state="0";
						log "Loading dump..."
						sed 's/devicehistory/deviceHistory/g' < $path | mysql -h $host -P $port -u$user -p$pass "irzserver$version";
						if [[ ! "$?" = 0 ]]
						then
							load_state="-1";
							log "Error: Loading dump failed.";
						else
							log "Dump accepted.";
						fi;

						if [[ "$version" = "temp" && "$load_state" = "0" ]]
						then
							create_file="$(get_server_path temp/create.sql)";
							java -jar "$localpath/dist/DatabaseManager.jar" "m" $host $port $user $pass $create_file "$localpath/logs/Migration_$(date '+%d-%m-%Y_%H:%M:%S').txt";
							if [[ ! "$?" = 0 ]]
							then
								load_state="-1";
								log "Error: Migration failed.";
							else
								log "Migration finished. Database file created.";

								mysql -h $host -P $port -u$user -p$pass irzserver3 < $create_file;
								if [[ ! "$?" = 0 ]]
								then
									load_state="-1";
									log "Error: Loading created file failed.";
									break;
								fi;
							fi;
						fi;

						if [[ "$load_state" = "0" ]]
						then
							log "Complite: DB up to date.";
						else
							revert_database $path;
						fi;
					fi;
					break;;

				"From file")

					path=$(choose_file "importing");
					if [[ -n "$path" ]]
					then
						log "Creating dump of current DB...";
						mysqldump -h $host -P $port -u$user -p$pass --result-file="$(get_server_path temp/dump.sql)" irzserver3;
						log "Success.";

						java -Dlog4j2.loggerContextFactory=org.apache.logging.log4j.simple.SimpleLoggerContextFactory -jar "$localpath/dist/DatabaseManager.jar" "f" "-H" $host "-P" $port "-u" $user "-p" $pass "-f" $path > "$localpath/logs/Importing_$(date '+%d-%m-%Y_%H:%M:%S').txt";
						if [[ "$?" = 0 ]]
						then
							log "Importing finished. Database up to date.";
						else
							log "Error: Importing failed.";
							revert_database $path;
						fi;

					fi;
					break;;

				Cancel)
					break;;
				esac;
			done;;

		"$(check_service)")

			turn_server;;
		
		Status)

			upd_parameters;
			print_status;;
			
		Exit)
			echo "Bye";
			turner="TERMINATE";

		esac;
		break;
	done;
done;
