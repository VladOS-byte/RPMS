#!/bin/bash

export NCURSES_NO_UTF8_ACS=0


# localpath=$(echo $0 | sed "s/\/configserver.sh$//g")
localpath="/usr/local/iRZ_Dispatcher/"

cd "$localpath"

if [ ! -d "$localpath/logs" ]
then
        mkdir "$localpath/logs";
fi;

LC_ALL="ru_RU.CP1251" nohup $(which java) -Xms256m -jar "dist/Dispatcher.jar" >logs/irz.out 2> logs/irz.err  &